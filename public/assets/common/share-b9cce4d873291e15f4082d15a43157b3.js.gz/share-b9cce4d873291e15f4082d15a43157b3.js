$(document).ready(function(){
  $('#share_vk').html(VK.Share.button(false,{type: "custom", text: "<span class='glyphicon glyphicon-heart'></span><span> Поделиться</span>"}));
  $()
});
